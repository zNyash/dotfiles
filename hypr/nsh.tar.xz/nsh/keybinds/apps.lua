-- Terminal
hl.unbind("SUPER + Q")
hl.bind("SUPER + Q", hl.dsp.exec_cmd(Terminal))

-- File Manager
hl.unbind("SUPER + E")
hl.bind("SUPER + E", hl.dsp.exec_cmd(FileManager))

-- Discord
hl.unbind("SUPER + D")
hl.bind("SUPER + D", hl.dsp.exec_cmd(Discord))

-- Browser
hl.unbind("SUPER + B")
hl.bind("SUPER + B", hl.dsp.exec_cmd(Browser))

-- Coding Editor
hl.unbind("SUPER + ALT + C")
hl.bind("SUPER + ALT + C", hl.dsp.exec_cmd(CodingEditor))

-- Github Desktop
hl.unbind("SUPER + G")
hl.bind("SUPER + G", hl.dsp.exec_cmd(GithubDesktop))

-- Launcher
hl.unbind("SUPER + R")
hl.bind("SUPER + R", hl.dsp.exec_cmd(Launcher))

-- Lock menu
hl.unbind("SUPER + L")
hl.bind("SUPER + L", hl.dsp.exec_cmd(MenuLock))

-- Clipboard menu
hl.unbind("SUPER + V")
hl.bind("SUPER + V", hl.dsp.exec_cmd(MenuClipboard))

hl.unbind("SUPER + SHIFT + S")
hl.bind("SUPER + SHIFT + S", hl.dsp.exec_cmd(ScreenshotRegion))

-- hl.bind("SUPER + L", hl.dsp.exec_cmd("noctalia msg panel-toggle session"))            -- Session
-- hl.bind("SUPER + V", hl.dsp.exec_cmd("noctalia msg panel-toggle clipboard"))          -- Clipboard
-- hl.bind("SUPER + W", hl.dsp.exec_cmd("noctalia msg panel-toggle wallpaper"))          -- Clipboard
-- hl.bind("SUPER + SLASH", hl.dsp.exec_cmd("noctalia msg panel-toggle control-center")) -- Clipboard
