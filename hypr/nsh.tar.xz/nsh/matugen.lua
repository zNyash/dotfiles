hl.config({
    general = {
        col = {
            active_border   = "rgb(b0c6ff)",
            inactive_border = "rgb(44464f)",
        },
    },
    misc = {
        background_color = "rgba(121318FF)",
    },
})

hl.window_rule({
    match        = { pin = 1 },
    border_color = "rgba(b0c6ffAA) rgba(b0c6ff77)",
})
